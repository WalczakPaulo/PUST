%Uaktualniony punkt pracy
%Uwaga w srodku laduja s.mat, odpowiednio pozmieniac !!
function[s] = normalizacja(s)

    s = (s - s(1))/20

end